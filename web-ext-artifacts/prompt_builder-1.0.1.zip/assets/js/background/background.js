browser.browserAction.onClicked.addListener(() => {
  console.log("shit");
  browser.sidebarAction.open();
});
