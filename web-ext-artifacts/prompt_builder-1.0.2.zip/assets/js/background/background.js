browser.browserAction.onClicked.addListener(() => {
  browser.sidebarAction.open();
});
