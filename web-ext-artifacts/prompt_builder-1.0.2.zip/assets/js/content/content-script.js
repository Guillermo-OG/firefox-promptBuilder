function insertTextAtCursor(text) {
  const activeElement = document.activeElement;
  const start = activeElement.selectionStart;
  const end = activeElement.selectionEnd;
  const value = activeElement.value;

  if (value.length > 0 && start === end) {
    text = " " + text;
  }

  activeElement.value = value.slice(0, start) + text + value.slice(end);
  activeElement.selectionStart = start + text.length;
  activeElement.selectionEnd = start + text.length;
  activeElement.focus();

  const event = new KeyboardEvent("input", { data: text });
  activeElement.dispatchEvent(event);
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "insertText") {
    insertTextAtCursor(message.text);
  }
});
