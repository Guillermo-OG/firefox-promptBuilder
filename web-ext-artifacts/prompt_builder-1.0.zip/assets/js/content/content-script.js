function insertTextAtCursor(text) {
  const activeElement = document.activeElement;
  const start = activeElement.selectionStart;
  const end = activeElement.selectionEnd;
  const value = activeElement.value;

  if (value.length > 0 && start === end) {
    text = " " + text;
  }

  const insertChar = (char, delay, isLastChar) => {
    setTimeout(() => {
      const currentStart = activeElement.selectionStart;
      const currentEnd = activeElement.selectionEnd;
      const currentValue = activeElement.value;

      activeElement.value =
        currentValue.slice(0, currentStart) +
        char +
        currentValue.slice(currentEnd);
      activeElement.selectionStart = currentStart + 1;
      activeElement.selectionEnd = currentStart + 1;
      activeElement.focus();

      if (isLastChar) {
        const event = new KeyboardEvent("keydown", { key: char });
        activeElement.dispatchEvent(event);
      }
    }, delay);
  };

  for (let i = 0; i < text.length; i++) {
    const isLastChar = i === text.length - 1;
    insertChar(text[i], i * 15, isLastChar); // 100 ms de retardo entre caracteres
  }
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "insertText") {
    insertTextAtCursor(message.text);
  }
});
