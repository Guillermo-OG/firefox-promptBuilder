import folderManager from "/assets/js/sidebar/manager/folderManager.js";
import textBlockManager from "/assets/js/sidebar/manager/textBlockManager.js";
import * as domUtils from "/assets/js/sidebar/utils/domUtils.js";
import {
  addTextBlockButton,
  saveTextBlockButton,
  cancelTextBlockButton,
  createFolderButton,
  modalContainer,
  editModeButton,
  titleInput,
  textArea,
  folderDropdown,
  state,
} from "/assets/js/sidebar/sidebar.js";

export function initEventListeners() {
  const folders =
    JSON.parse(localStorage.getItem("promptBuilderFolders")) || [];
  console.log("ta importando certinho");
  // Agregar eventListeners aquí
  addTextBlockButton.addEventListener("click", () => {
    domUtils.showModal(modalContainer);
    const currentFolder = folders.find(
      (folder) => folder.id === state.currentFolderId
    );
    folderManager.updateFolderDropdown(currentFolder);
  });

  saveTextBlockButton.addEventListener("click", () => {
    let title = titleInput.value.trim();
    const text = textArea.value.trim();
    const folderId = folderDropdown.value;

    if (title && text) {
      title = title.charAt(0).toUpperCase() + title.slice(1);
      const textBlock = {
        id: new Date().getTime(),
        title: title,
        text: text,
        folderId: folderId,
      };

      textBlockManager.addTextBlock(textBlock);

      // Limpiar los campos de entrada en la UI
      titleInput.value = "";
      textArea.value = "";

      domUtils.hideModal(modalContainer);
    } else {
      alert("Please fill in both title and text fields.");
    }
  });

  editModeButton.addEventListener("click", () => {
    toggleEditMode();
  });

  cancelTextBlockButton.addEventListener("click", () => {
    domUtils.hideModal(modalContainer);
  });
  createFolderButton.addEventListener("click", () => {
    const folderName = prompt("Enter the folder name:");
    const folderId = folderDropdown.value;

    if (folderName) {
      folderManager.addFolder(folderName, folderId);
    }
  });
}

export function initUI() {
  folderManager.updateFoldersList();
  textBlockManager.updateTextBlocksList();
  folderManager.updateFolderDropdown();
}

let isEditMode = false;

function toggleEditMode() {
  isEditMode = !isEditMode;

  if (isEditMode) {
    // Activar el modo de edición
    document.body.classList.add("edit-mode");
    editModeButton.classList.remove("edit-mode-button-active");
  } else {
    disableEditMode();
  }
}

export function disableEditMode() {
  // Desactivar el modo de edición
  isEditMode = false;
  document.body.classList.remove("edit-mode");
  editModeButton.classList.add("edit-mode-button-active");
}
