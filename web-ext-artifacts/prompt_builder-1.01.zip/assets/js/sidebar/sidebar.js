import { initEventListeners, initUI } from "/assets/js/sidebar/init/init.js";
import * as folderManager from "/assets/js/sidebar/manager/folderManager.js";
import * as textBlockManager from "/assets/js/sidebar/manager/textBlockManager.js";
import * as domUtils from "/assets/js/sidebar/utils/domUtils.js";

const state = {
  currentFolderId: "0",
};

const SELECTORS = {
  breadcrumbContainer: "breadcrumb-container",
  mainContainer: "main-container",
  modalContainer: "modal-container",
  addTextBlockButton: "add-text-block",
  saveTextBlockButton: "save-text-block",
  editModeButton: "edit-mode-button",
  cancelTextBlockButton: "cancel-text-block",
  folderDropdown: "folder-dropdown",
  createFolderButton: "create-folder",
  foldersList: "folders-list",
  titleInput: "title-input",
  textArea: "text-area",
  textBlocksList: "text-blocks-list",
};

const mainContainer = document.getElementById(SELECTORS.mainContainer);
const modalContainer = document.getElementById(SELECTORS.modalContainer);
const addTextBlockButton = document.getElementById(
  SELECTORS.addTextBlockButton
);
const saveTextBlockButton = document.getElementById(
  SELECTORS.saveTextBlockButton
);
const cancelTextBlockButton = document.getElementById(
  SELECTORS.cancelTextBlockButton
);
const folderDropdown = document.getElementById(SELECTORS.folderDropdown);
const createFolderButton = document.getElementById(
  SELECTORS.createFolderButton
);
const foldersList = document.getElementById(SELECTORS.foldersList);
const titleInput = document.getElementById(SELECTORS.titleInput);
const textArea = document.getElementById(SELECTORS.textArea);
const textBlocksList = document.getElementById(SELECTORS.textBlocksList);
const breadcrumbContainer = document.getElementById(
  SELECTORS.breadcrumbContainer
);
const editModeButton = document.getElementById(SELECTORS.editModeButton);
// Llamar a las funciones de inicialización
document.addEventListener("DOMContentLoaded", () => {
  initEventListeners();
  initUI();
});

export {
  mainContainer,
  modalContainer,
  addTextBlockButton,
  saveTextBlockButton,
  cancelTextBlockButton,
  folderDropdown,
  createFolderButton,
  foldersList,
  titleInput,
  textArea,
  textBlocksList,
  breadcrumbContainer,
  editModeButton,
  state,
};
